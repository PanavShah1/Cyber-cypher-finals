Getting ready for winning the Cyber Cypher Contest in Taqneeqfest!
